set -e
A=control-music
mkdir -p www
cp $A/index.html $A/manifest.json $A/sw.js $A/icon-192.png $A/icon-512.png www/
npm init -y > /dev/null
npm i @capacitor/core@7 @capacitor/cli@7 @capacitor/android@7
npx cap init "Control Music" com.controlmusic.app --web-dir=www
npx cap add android
python3 $A/patch.py
R=android/app/src/main/res
rm -rf $R/mipmap-anydpi-v26
cp -r $A/res/* $R/
find $R -name 'splash.png' -exec cp $A/black.png {} \;
npx cap sync android
