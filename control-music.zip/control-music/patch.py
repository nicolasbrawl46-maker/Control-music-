import glob
m = 'android/app/src/main/AndroidManifest.xml'
s = open(m).read()
f = '''
        <intent-filter>
            <action android:name="android.intent.action.SEND" />
            <category android:name="android.intent.category.DEFAULT" />
            <data android:mimeType="audio/*" />
            <data android:mimeType="video/*" />
        </intent-filter>
        <intent-filter>
            <action android:name="android.intent.action.SEND_MULTIPLE" />
            <category android:name="android.intent.category.DEFAULT" />
            <data android:mimeType="audio/*" />
            <data android:mimeType="video/*" />
            <data android:mimeType="*/*" />
        </intent-filter>
        <intent-filter>
            <action android:name="android.intent.action.VIEW" />
            <category android:name="android.intent.category.DEFAULT" />
            <category android:name="android.intent.category.BROWSABLE" />
            <data android:scheme="content" />
            <data android:scheme="file" />
            <data android:mimeType="audio/*" />
            <data android:mimeType="video/*" />
        </intent-filter>
    '''
assert '</activity>' in s
open(m, 'w').write(s.replace('</activity>', f + '</activity>', 1))
p = glob.glob('android/app/src/main/java/**/MainActivity.java', recursive=True)[0]
open(p, 'w').write(open('control-music/MainActivity.java').read())
print('patched', p)
