package com.controlmusic.app;

import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import com.getcapacitor.BridgeActivity;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import org.json.JSONArray;
import org.json.JSONObject;

public class MainActivity extends BridgeActivity {
  private JSONArray pending = new JSONArray();

  public class ShareApi {
    @JavascriptInterface
    public String take() {
      synchronized (MainActivity.this) {
        String s = pending.toString();
        pending = new JSONArray();
        return s;
      }
    }
  }

  @Override
  public void onCreate(Bundle b) {
    super.onCreate(b);
    WebView w = getBridge().getWebView();
    w.getSettings().setMediaPlaybackRequiresUserGesture(false);
    w.addJavascriptInterface(new ShareApi(), "AndroidShare");
    handle(getIntent());
  }

  @Override
  public void onNewIntent(Intent i) {
    super.onNewIntent(i);
    setIntent(i);
    handle(i);
  }

  @Override
  public void onPause() {
    super.onPause();
    try {
      WebView w = getBridge().getWebView();
      w.onResume();
      w.resumeTimers();
    } catch (Exception e) {}
  }

  private void handle(Intent i) {
    if (i == null) return;
    String a = i.getAction();
    final ArrayList<Uri> uris = new ArrayList<>();
    try {
      if (Intent.ACTION_SEND.equals(a)) {
        Uri u = (Uri) i.getParcelableExtra(Intent.EXTRA_STREAM);
        if (u != null) uris.add(u);
      } else if (Intent.ACTION_SEND_MULTIPLE.equals(a)) {
        ArrayList<Uri> l = i.getParcelableArrayListExtra(Intent.EXTRA_STREAM);
        if (l != null) uris.addAll(l);
      } else if (Intent.ACTION_VIEW.equals(a) && i.getData() != null) {
        uris.add(i.getData());
      }
    } catch (Exception e) {}
    if (uris.isEmpty()) return;
    i.setAction(null);
    new Thread(() -> {
      JSONArray out = new JSONArray();
      for (Uri u : uris) {
        try {
          String name = "musica";
          try (Cursor c = getContentResolver().query(u, null, null, null, null)) {
            if (c != null && c.moveToFirst()) {
              int ix = c.getColumnIndex(OpenableColumns.DISPLAY_NAME);
              if (ix >= 0) name = c.getString(ix);
            }
          } catch (Exception e) {}
          if (name == null) name = "musica";
          File dir = new File(getCacheDir(), "shared");
          dir.mkdirs();
          File f = new File(dir, System.currentTimeMillis() + "_" + name.replaceAll("[^A-Za-z0-9._-]", "_"));
          try (InputStream in = getContentResolver().openInputStream(u); FileOutputStream os = new FileOutputStream(f)) {
            byte[] buf = new byte[65536];
            int n;
            while ((n = in.read(buf)) > 0) os.write(buf, 0, n);
          }
          JSONObject o = new JSONObject();
          o.put("name", name);
          o.put("path", f.getAbsolutePath());
          out.put(o);
        } catch (Exception e) {}
      }
      synchronized (MainActivity.this) {
        for (int k = 0; k < out.length(); k++) {
          try { pending.put(out.get(k)); } catch (Exception e) {}
        }
      }
      runOnUiThread(() -> {
        try {
          getBridge().getWebView().evaluateJavascript("window.__takeShared&&window.__takeShared()", null);
        } catch (Exception e) {}
      });
    }).start();
  }
}
